def retorna_menor(a):
  menor = a[0]
  x = 0
  for i in range(1, len(a)):
    if a[i] < menor:
      menor = a[i]
      x = i
  return x


def oredencao(a):
  b=[]
  for _i in range(0, len(a)):
    x = retorna_menor(a)
    b.append(a.pop(x))
  return b

  
array = [5, 3, 1, 2, 4]
array = oredencao(array)
print(array)